/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, useEffect, useRef } from "react";
import { motion, AnimatePresence } from "motion/react";
import { 
  Building2, 
  GraduationCap, 
  Radio, 
  Trophy, 
  Users, 
  Mail, 
  MapPin, 
  Globe,
  ChevronRight,
  Tv2,
  Mic2,
  Award,
  Phone,
  MessageCircle,
  Menu,
  X,
  Twitter,
  Play
} from "lucide-react";

export default function App() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const menuRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (isMenuOpen) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = 'unset';
    }
  }, [isMenuOpen]);

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 20);
    };
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  const navLinks = [
    { name: "About", href: "#about" },
    { name: "Leadership", href: "#leadership" },
    { name: "Achievements", href: "#achievements" },
    { name: "Contact", href: "#contact" }
  ];
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: { 
      opacity: 1,
      transition: { 
        staggerChildren: 0.1,
        delayChildren: 0.2
      }
    }
  };

  const itemVariants = {
    hidden: { y: 20, opacity: 0 },
    visible: { 
      y: 0, 
      opacity: 1,
      transition: { duration: 0.8, ease: [0.16, 1, 0.3, 1] }
    }
  };

  return (
    <div className="min-h-screen bg-[#fbfaf8] text-[#131313] font-sans selection:bg-[#131110] selection:text-white">
      <a 
        href="#main-content" 
        className="sr-only focus:not-sr-only focus:fixed focus:top-4 focus:left-4 focus:z-[100] focus:px-4 focus:py-2 focus:bg-black focus:text-white focus:rounded-md"
      >
        Skip to main content
      </a>

      {/* Navigation */}
      <nav className={`fixed top-0 w-full z-50 px-6 md:px-12 transition-all duration-500 border-b ${scrolled ? 'py-2 bg-white border-black/10 shadow-md' : 'py-4 bg-[#fbfaf8] border-black/5'}`}>
        <div className="max-w-7xl mx-auto flex justify-between items-center">
          <button 
            className="font-serif text-xl md:text-2xl tracking-tighter font-bold cursor-pointer group focus-visible:outline-2 focus-visible:outline-offset-4 focus-visible:outline-black" 
            onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}
            aria-label="Back to top"
          >
            K. <span className="italic group-hover:pl-1 transition-all duration-300">Kaliisa</span>
          </button>
          
          {/* Desktop Nav */}
          <div className="hidden md:flex items-center gap-12">
            <div className="flex gap-10 text-[10px] uppercase tracking-[0.2em] font-bold">
              {navLinks.map((link) => (
                <a 
                  key={link.name} 
                  href={link.href} 
                  className="relative group py-2 focus-visible:outline-2 focus-visible:outline-offset-4 focus-visible:outline-black"
                >
                  <span className="group-hover:opacity-60 transition-opacity font-bold">{link.name}</span>
                  <span className="absolute bottom-0 left-0 w-0 h-[1.5px] bg-black transition-all duration-300 group-hover:w-full"></span>
                </a>
              ))}
            </div>
          </div>

          {/* Mobile Nav Toggle */}
          <button 
            className="md:hidden p-2 -mr-2 z-50 flex items-center justify-center transition-transform active:scale-90 bg-black/5 rounded-full focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-black"
            onClick={() => setIsMenuOpen(!isMenuOpen)}
            aria-label={isMenuOpen ? "Close menu" : "Open menu"}
            aria-expanded={isMenuOpen}
            aria-controls="mobile-menu"
          >
            {isMenuOpen ? <X className="w-5 h-5" aria-hidden="true" /> : <Menu className="w-5 h-5" aria-hidden="true" />}
          </button>
        </div>

        {/* Mobile Menu Overlay */}
        <AnimatePresence>
          {isMenuOpen && (
            <motion.div 
              id="mobile-menu"
              ref={menuRef}
              role="dialog"
              aria-modal="true"
              aria-label="Navigation menu"
              initial={{ opacity: 0, scale: 1.05 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 1.05 }}
              transition={{ duration: 0.4, ease: [0.16, 1, 0.3, 1] }}
              className="fixed inset-0 bg-[#fbfaf8] z-40 md:hidden flex flex-col p-8 pt-24"
            >
              <div className="flex flex-col gap-4">
                {navLinks.map((link, idx) => (
                  <motion.a 
                    key={link.name} 
                    href={link.href}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: 0.1 + idx * 0.1, duration: 0.6 }}
                    onClick={() => setIsMenuOpen(false)}
                    className="font-serif text-4xl sm:text-5xl font-light hover:italic transition-all flex items-center justify-between group py-2 focus-visible:outline-2 focus-visible:outline-offset-4 focus-visible:outline-black"
                  >
                    <span>{link.name}</span>
                    <ChevronRight className="w-8 h-8 opacity-0 group-hover:opacity-40 -translate-x-4 group-hover:translate-x-0 transition-all" aria-hidden="true" />
                  </motion.a>
                ))}
              </div>
              
              <div className="mt-auto pt-10 border-t border-black/5">
                <span className="text-[10px] uppercase tracking-widest font-bold opacity-30 block mb-6">Stay Connected</span>
                <div className="flex flex-col sm:flex-row gap-3">
                  <a href="https://wa.me/256708349500" target="_blank" rel="noreferrer" className="flex-1 py-4 bg-black/5 rounded-2xl flex items-center justify-center gap-3 active:bg-black/10 transition-colors font-bold uppercase tracking-widest text-[10px] focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-black" aria-label="Chat on WhatsApp">
                    <MessageCircle className="w-5 h-5 text-green-600" aria-hidden="true" /> WhatsApp
                  </a>
                  <a href="mailto:Karimkaliisa1970@gmail.com" className="flex-1 py-4 bg-black/5 rounded-2xl flex items-center justify-center gap-3 active:bg-black/10 transition-colors font-bold uppercase tracking-widest text-[10px] focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-black" aria-label="Send Email">
                    <Mail className="w-5 h-5" aria-hidden="true" /> Email
                  </a>
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </nav>

      {/* Hero Section */}
      <section className="relative min-h-screen flex items-center px-6 md:px-24 overflow-hidden border-b border-black/5 bg-white pt-20">
        <div className="max-w-5xl z-10 w-full">
          <motion.div 
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 1.2, ease: [0.16, 1, 0.3, 1] }}
          >
            <h1 className="font-serif text-5xl sm:text-7xl md:text-9xl leading-[0.95] tracking-tighter mb-10">
              Hajji Karim <br />
              <span className="italic pl-0 md:pl-20 block md:inline mt-2 md:mt-0">Kaliisa</span>
            </h1>
            <div className="flex flex-col md:flex-row gap-10 md:gap-16 items-start">
              <p className="max-w-md text-lg md:text-xl leading-relaxed opacity-70 font-light">
                A visionary media entrepreneur and executive with over 22 years of experience in NGO & Media Administration, Consulting, and ICT development.
              </p>
              <div className="flex gap-4 items-center">
                <div className="h-[1px] w-12 bg-black/20 hidden sm:block" aria-hidden="true"></div>
                <div className="text-[10px] uppercase tracking-[0.2em] font-bold flex flex-col gap-3 opacity-50">
                  <span>Next Media Group</span>
                  <span>Pearl FM</span>
                  <span>Voice of Africa</span>
                </div>
              </div>
            </div>
          </motion.div>
        </div>
        
        {/* Background Graphic */}
        <div className="absolute right-[-10%] top-1/2 -translate-y-1/2 w-full md:w-1/2 h-4/5 grayscale opacity-[0.05] md:opacity-[0.1] blur-sm select-none pointer-events-none -z-0" aria-hidden="true">
           <div className="w-full h-full border border-black rounded-full overflow-hidden flex items-center justify-center p-8 scale-150 md:scale-100">
              <div className="w-full h-full border border-black rounded-full p-8 flex items-center justify-center">
                 <Radio className="w-64 h-64" />
              </div>
           </div>
        </div>
      </section>

      {/* Content Container */}
      <main id="main-content" className="max-w-7xl mx-auto px-6 md:px-12 py-20 md:py-32">
        
        {/* Biography/About */}
        <section id="about" className="mb-32 md:mb-56">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 md:gap-20">
            <div className="lg:col-span-4">
              <h2 className="font-serif text-4xl md:text-5xl italic mb-6">The Mission</h2>
              <div className="h-px w-full bg-black/10"></div>
            </div>
            <div className="lg:col-span-8">
              <div className="space-y-8 text-lg md:text-2xl leading-relaxed opacity-80 font-light">
                <p>
                  Hajji Karim Kaliisa is a distinguished leader whose career spans more than two decades at the forefront of East African media and development. His expertise bridges the gap between infrastructure, information technology, and social progress.
                </p>
                <p>
                  As an Executive Manager Marshalling complex media organizations and NGO administrations, he has consistently delivered exceptional results in management consulting and media entrepreneurship, leveraging ICT to enhance development for all.
                </p>
              </div>
            </div>
          </div>
        </section>

        {/* Leadership Grid */}
        <section id="leadership" className="mb-32 md:mb-56">
          <div className="mb-12 md:mb-20 text-center md:text-left">
            <span className="text-[10px] uppercase tracking-[0.3em] font-bold opacity-30">Governance & Direction</span>
            <h2 className="font-serif text-5xl md:text-7xl mt-4 leading-tight">Leadership Roles</h2>
          </div>

          <motion.div 
            variants={containerVariants}
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true }}
            className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-px bg-black/5 border border-black/5 rounded-3xl overflow-hidden shadow-sm"
          >
            {[
              { 
                title: "Next Media Service", 
                role: "Board Member", 
                desc: "Overseeing NBS TV, Sanyuka TV, Salam TV, Next Radio, Nile Post, and Next Communications.",
                icon: Tv2 
              },
              { 
                title: "Voice of Africa Radio", 
                role: "Executive Director", 
                desc: "Lead executive and board member for one of the region's most influential radio networks.",
                icon: Radio 
              },
              { 
                title: "Pearl FM", 
                role: "Resident Director", 
                desc: "Strategic leadership of one of the major broadcasting stations in Kampala and beyond.",
                icon: Mic2 
              },
              { 
                title: "Judicial Service Commission", 
                role: "Lead Consultant", 
                desc: "Conducting feasibility and technical studies for nationwide MOS regional radio stations.",
                icon: Building2 
              },
              { 
                title: "National Broadcasters Association", 
                role: "Member", 
                desc: "Active participation in the industry body shaping broadcasting policy and standards.",
                icon: Users 
              },
              { 
                title: "Kampala High School", 
                role: "Board Member", 
                desc: "Contributing to educational governance and community development through social centers.",
                icon: GraduationCap 
              }
            ].map((item, idx) => (
              <motion.div 
                key={idx}
                variants={itemVariants}
                className="bg-[#fbfaf8] p-10 hover:bg-black group transition-colors duration-500"
              >
                <item.icon className="w-8 h-8 mb-8 group-hover:text-white transition-colors duration-500" strokeWidth={1} />
                <h3 className="font-serif text-2xl group-hover:text-white transition-colors duration-500 mb-2">{item.title}</h3>
                <p className="text-xs uppercase tracking-widest font-bold text-black/40 group-hover:text-white/40 mb-6">{item.role}</p>
                <p className="text-sm leading-relaxed opacity-60 group-hover:text-white/60 group-hover:opacity-100 transition-all duration-500">
                  {item.desc}
                </p>
              </motion.div>
            ))}
          </motion.div>
        </section>

        {/* Achievements Timeline */}
        <section id="achievements" className="mb-32 md:mb-56">
          <div className="flex flex-col lg:flex-row gap-16 md:gap-24">
            <div className="lg:w-1/3">
              <div className="lg:sticky lg:top-32">
                <span className="text-[10px] uppercase tracking-[0.3em] font-bold opacity-30">Strategic Impact</span>
                <h2 className="font-serif text-5xl md:text-6xl mt-4 mb-8 leading-tight">Career <br className="hidden lg:block"/>Impact</h2>
                <p className="text-base opacity-60 max-w-sm leading-relaxed font-light">
                  Pioneering media technology across East and Central Africa through international partnerships and infrastructure development.
                </p>
              </div>
            </div>
            
            <div className="lg:w-2/3 space-y-20 md:space-y-32">
              {[
                {
                  year: "Continental Expansion",
                  title: "Regional Broadcasting Network",
                  desc: "Led the strategic establishment and management of the Voice of Africa radio network across the Great Lakes region. This involved navigating complex regulatory environments to launch operations in Uganda, Rwanda (AMUR), Burundi (World Islamic Call Society), and the DRC (COMICO), fostering regional integration through broadcasting."
                },
                {
                  year: "Media Technology",
                  title: "International Partnerships & FDI",
                  desc: "Spearheaded high-level media technology partnerships between Turkey and East Africa. Successfully introduced state-of-the-art Italian FDI FM/TV Broadcasting Equipment (RVR) to the region, modernizing the technical infrastructure of numerous national and private broadcasters."
                },
                {
                  year: "Journalism Development",
                  title: "Human Capital & Professional Training",
                  desc: "Orchestrated comprehensive professional development programs for hundreds of Ugandan media practitioners. Through strategic partnerships with the SENA Foundation and TiKA in Turkey, these initiatives significantly elevated journalism standards and technical expertise within the Ugandan media landscape."
                },
                {
                  year: "Community Growth",
                  title: "Social Development & NGO Leadership",
                  desc: "Mobilized extensive community resources to drive sustainable social development. This initiative resulted in the successful establishment of numerous schools, modern health units, and vibrant social centers, empowering local populations towards self-reliance and civic confidence."
                }
              ].map((achievement, idx) => (
                <motion.div 
                  key={idx} 
                  initial={{ opacity: 0, x: 20 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.8, delay: idx * 0.1 }}
                  className="group"
                >
                  <div className="flex items-center gap-6 mb-6">
                    <div className="h-px flex-grow bg-black/5 group-hover:bg-black/20 transition-all duration-700"></div>
                    <span className="font-mono text-[10px] opacity-40 uppercase tracking-widest">{achievement.year}</span>
                  </div>
                  <h3 className="font-serif text-3xl md:text-5xl mb-6 group-hover:translate-x-4 transition-transform duration-700 leading-tight">{achievement.title}</h3>
                  <p className="text-lg md:text-xl opacity-70 mb-8 leading-relaxed max-w-2xl font-light">
                    {achievement.desc}
                  </p>
                </motion.div>
              ))}
            </div>
          </div>
        </section>

        {/* Education Section */}
        <section className="mb-32 md:mb-56 bg-black text-white p-8 md:p-24 rounded-[32px] md:rounded-[60px] overflow-hidden relative">
          <div className="relative z-10">
            <h2 className="font-serif text-5xl md:text-7xl mb-16 md:mb-24 italic tracking-tight">Academic Background</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-16 md:gap-32">
              <motion.div 
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
              >
                <span className="text-[10px] uppercase tracking-[0.3em] opacity-40 block mb-6 font-bold" id="makerere-edu-1">Makerere University</span>
                <h3 className="text-3xl md:text-4xl mb-6 font-medium leading-tight" aria-labelledby="makerere-edu-1">Master of Arts in <br/>Human Rights</h3>
                <p className="text-xl text-white/50 leading-relaxed italic mb-4 font-light">
                  Thesis: "Family Law and the promotion of Gender Equity"
                </p>
                <div className="h-px w-12 bg-white/20 mt-8" aria-hidden="true"></div>
              </motion.div>
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: 0.2 }}
              >
                <span className="text-[10px] uppercase tracking-[0.3em] opacity-40 block mb-6 font-bold" id="makerere-edu-2">Makerere University</span>
                <h3 className="text-3xl md:text-4xl mb-6 font-medium leading-tight" aria-labelledby="makerere-edu-2">BA in Sociology</h3>
                <p className="text-xl text-white/50 leading-relaxed mb-4 font-light">
                  Class of 1996
                </p>
                <div className="h-px w-12 bg-white/20 mt-8" aria-hidden="true"></div>
              </motion.div>
            </div>
          </div>
          
          {/* Decorative Ring */}
          <div className="absolute right-[-10%] bottom-[-10%] w-[400px] h-[400px] md:w-[600px] md:h-[600px] border border-white/5 rounded-full select-none pointer-events-none"></div>
          <div className="absolute right-[-5%] bottom-[-5%] w-[250px] h-[250px] md:w-[400px] md:h-[400px] border border-white/10 rounded-full select-none pointer-events-none"></div>
        </section>

        {/* Detailed Contact Section */}
        <section id="contact" className="py-24 md:py-40 border-t border-black/10">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-16 md:gap-24 items-start">
            <div className="lg:col-span-5">
              <motion.div
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 1 }}
              >
                <div className="flex items-center gap-3 mb-8">
                  <div className="w-2 h-2 rounded-full bg-green-500 animate-pulse shadow-[0_0_10px_rgba(34,197,94,0.4)]"></div>
                  <span className="text-[10px] uppercase tracking-[0.3em] font-bold opacity-40">Direct Consultation</span>
                </div>
                
                <h2 className="font-serif text-6xl md:text-8xl mb-10 leading-[0.9] tracking-tighter">
                  Let's shape the <br />
                  <span className="italic">future</span> of media.
                </h2>
                
                <p className="text-lg md:text-2xl opacity-60 font-light max-w-sm leading-relaxed mb-12">
                  Available for executive consulting, board membership, and strategic media development across East Africa.
                </p>

                <div className="space-y-4 pt-12 border-t border-black/5">
                  <div className="flex justify-between items-center text-[10px] uppercase tracking-widest font-bold opacity-30">
                    <span>Response Time</span>
                    <span>Within 24 Hours</span>
                  </div>
                </div>
              </motion.div>
            </div>

            <div className="lg:col-span-1"></div>

            <div className="lg:col-span-6">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-px bg-black/5 border border-black/5 rounded-[40px] overflow-hidden shadow-sm">
                {[
                  {
                    label: "Professional Correspondence",
                    value: "Karimkaliisa1970@gmail.com",
                    href: "mailto:Karimkaliisa1970@gmail.com",
                    icon: Mail,
                    className: "sm:col-span-2"
                  },
                  {
                    label: "Executive Direct Line",
                    value: "+256 708 349 500",
                    href: "tel:+256708349500",
                    icon: Phone
                  },
                  {
                    label: "Strategic Partnerships",
                    value: "+256 772 423 827",
                    href: "tel:+256772423827",
                    icon: Phone
                  },
                  {
                    label: "Industry Insights (X)",
                    value: "@hajjikaliisa",
                    href: "https://x.com/hajjikaliisa?s=21",
                    icon: Twitter
                  },
                  {
                    label: "Media Content (TikTok)",
                    value: "@karim.kaliisa",
                    href: "https://www.tiktok.com/@karim.kaliisa?_r=1&_t=ZS-96CoKtUNVDU",
                    icon: Play
                  }
                ].map((contact, idx) => (
                  <motion.a
                    key={idx}
                    href={contact.href}
                    target={contact.href.startsWith('http') ? "_blank" : undefined}
                    rel={contact.href.startsWith('http') ? "noreferrer" : undefined}
                    initial={{ opacity: 0 }}
                    whileInView={{ opacity: 1 }}
                    viewport={{ once: true }}
                    transition={{ delay: idx * 0.1 }}
                    className={`${contact.className || ''} bg-[#fbfaf8] p-10 md:p-12 flex flex-col justify-between min-h-[220px] md:min-h-[260px] hover:bg-black group transition-all duration-700 focus-visible:outline-2 focus-visible:outline-offset-[-2px] focus-visible:outline-black`}
                  >
                    <div className="flex justify-between items-start">
                      <div className="p-3 bg-black/5 rounded-full group-hover:bg-white/10 transition-colors duration-500">
                        <contact.icon className="w-6 h-6 opacity-40 group-hover:text-white group-hover:opacity-100 transition-all duration-500" strokeWidth={1.5} aria-hidden="true" />
                      </div>
                      <div className="w-8 h-8 rounded-full border border-black/5 flex items-center justify-center opacity-0 group-hover:opacity-100 -translate-y-2 group-hover:translate-y-0 transition-all duration-500 bg-white/10">
                        <ChevronRight className="w-4 h-4 text-white" />
                      </div>
                    </div>
                    <div>
                      <span className="text-[10px] uppercase tracking-[0.2em] font-bold opacity-30 group-hover:text-white/40 block mb-3 transition-colors">{contact.label}</span>
                      <span className="text-xl md:text-2xl font-serif font-medium tracking-tight group-hover:text-white transition-colors break-all leading-tight block">{contact.value}</span>
                    </div>
                  </motion.a>
                ))}
              </div>
            </div>
          </div>
        </section>
      </main>

      <footer className="max-w-7xl mx-auto px-6 md:px-12 pb-16 pt-8 flex flex-col md:flex-row justify-between items-center text-[10px] uppercase tracking-[0.4em] font-bold opacity-20 text-center gap-6">
        <div>© {new Date().getFullYear()} Hajji Karim Kaliisa</div>
        <div className="h-px w-12 bg-black md:hidden"></div>
        <div>Executive Media Consultant • Kampala, Uganda</div>
      </footer>
    </div>
  );
}
